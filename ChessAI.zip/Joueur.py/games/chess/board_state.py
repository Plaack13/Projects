#Peyton Laack <ppl48d>
class Coordinate():
    def __init__(self,x,y):
        self.x = x
        self.y = y

    #Returns coordinate of pieces in FEN form
    def AccCoord(self):
        notation = "abcdefghijklmnopqrstuvwxyz"
        return notation[self.x] + str(self.y+1)

class Piece():
    __slots__ = ['loc','color','rep','value']
    def __init__(self,location,col):
        self.loc = location
        self.color = col

    #Returns false as a normal piece is not an empty space
    def isEmpty(self):
        return 0

    def deepcopy(self):
        #Type returns class
        return type(self)(Coordinate(self.loc.x,self.loc.y),self.color)

class Pawn(Piece):
    def __init__(self,loc,col):
        super().__init__(loc,col)
        self.rep = 'p'
        self.value = 1

    #Generates all valid moves of the pawn piece, except for en passant
    def generate_valid_moves(self,board):
        board_lenx = len(board.pieces[0])
        board_leny = len(board.pieces)
        valid_moves = []

        #Gets Pawn Moves if the Pawn is a white piece
        if(self.color == 'w'):

            #Checks Directly in front of Pawn
            if(self.loc.y + 1 < board_leny): 
                if(board.pieces[self.loc.y + 1][self.loc.x].rep == 'e'):
                    valid_moves.append(self.loc.AccCoord() + Coordinate(self.loc.x,self.loc.y+1).AccCoord())

                    #Checks if it's pawns first move. If it is it allows it to move 2
                    if(self.loc.y == 1 and board.pieces[self.loc.y+2][self.loc.x].rep == 'e'):
                        valid_moves.append(self.loc.AccCoord() + Coordinate(self.loc.x,self.loc.y+2).AccCoord())
            
            #Checks if Pawn can attack
            if(self.loc.y + 1 < board_leny and self.loc.x + 1 < board_lenx): 
                if(board.pieces[self.loc.y + 1][self.loc.x + 1].color == 'b'):
                    valid_moves.append(self.loc.AccCoord() + Coordinate(self.loc.x+1,self.loc.y+1).AccCoord())

            if(self.loc.y + 1 < board_leny and self.loc.x - 1 >= 0):
                if(board.pieces[self.loc.y + 1][self.loc.x - 1].color == 'b'):
                   valid_moves.append(self.loc.AccCoord() + Coordinate(self.loc.x-1,self.loc.y+1).AccCoord())

        #Gets Pawn Moves if the Pawn is a black piece
        else:
            #Checks Directly in front of Pawn
            if(self.loc.y - 1 >= 0): 
                if(board.pieces[self.loc.y - 1][self.loc.x].rep == 'e'):
                    valid_moves.append(self.loc.AccCoord() + Coordinate(self.loc.x,self.loc.y-1).AccCoord())

                    #Checks if it's pawns first move. If it is it allws it to move 2
                    if(self.loc.y == 6 and board.pieces[self.loc.y-2][self.loc.x].rep == 'e'):
                        valid_moves.append(self.loc.AccCoord() + Coordinate(self.loc.x,self.loc.y-2).AccCoord())
            
            #Checks if the Pawn can attack
            if(self.loc.y - 1 >= 0 and self.loc.x + 1 < board_lenx): 
                if(board.pieces[self.loc.y - 1][self.loc.x + 1].color == 'w'):
                    valid_moves.append(self.loc.AccCoord() + Coordinate(self.loc.x+1,self.loc.y-1).AccCoord())

            if(self.loc.y -1 >= 0 and self.loc.x - 1 >= 0): 
                if(board.pieces[self.loc.y - 1][self.loc.x - 1].color == 'w'):
                    valid_moves.append(self.loc.AccCoord() + Coordinate(self.loc.x-1,self.loc.y-1).AccCoord())
        
        return valid_moves

class Knight(Piece):
    def __init__(self,loc,col):
        super().__init__(loc,col)
        self.rep = 'n'
        self.value = 3

    #Generates all valid moves of the knight piece
    def generate_valid_moves(self,board):
        board_lenx = len(board.pieces[0])
        board_leny = len(board.pieces)
        valid_moves = []

        #Checks to the left of Knight
        if(self.loc.x - 2 >= 0):
            if(self.loc.y - 1 >= 0):
                coor1 = Coordinate(self.loc.x-2,self.loc.y-1)
                p = board.grab_piece(coor1)
                if(p.color != self.color):
                    valid_moves.append(self.loc.AccCoord() + coor1.AccCoord())

            if(self.loc.y + 1 < board_leny):
                coor1 = Coordinate(self.loc.x-2,self.loc.y+1)
                p = board.grab_piece(coor1)
                if(p.color != self.color):
                    valid_moves.append(self.loc.AccCoord() + coor1.AccCoord())                

        #Checks to the right of Knight
        if(self.loc.x + 2 < board_lenx):
            if(self.loc.y - 1 >= 0):
                coor1 = Coordinate(self.loc.x+2,self.loc.y-1)
                p = board.grab_piece(coor1)
                if(p.color != self.color):
                    valid_moves.append(self.loc.AccCoord() + coor1.AccCoord())

            if(self.loc.y + 1  < board_leny):
                coor1 = Coordinate(self.loc.x+2,self.loc.y+1)
                p = board.grab_piece(coor1)
                if(p.color != self.color):
                    valid_moves.append(self.loc.AccCoord() + coor1.AccCoord())

        #Checks Below Knight
        if(self.loc.y - 2 >= 0):
            if(self.loc.x - 1 >= 0):
                coor1 = Coordinate(self.loc.x-1,self.loc.y-2)
                p = board.grab_piece(coor1)
                if(p.color != self.color):
                    valid_moves.append(self.loc.AccCoord() + coor1.AccCoord())

            if(self.loc.x + 1 < board_lenx):
                coor1 = Coordinate(self.loc.x+1,self.loc.y-2)
                p = board.grab_piece(coor1)
                if(p.color != self.color):
                    valid_moves.append(self.loc.AccCoord() + coor1.AccCoord())

        #Checks Above Knight
        if(self.loc.y + 2 < board_leny):
            if(self.loc.x - 1 >= 0):
                coor1 = Coordinate(self.loc.x-1,self.loc.y+2)
                p = board.grab_piece(coor1)
                if(p.color != self.color):
                    valid_moves.append(self.loc.AccCoord() + coor1.AccCoord())

            if(self.loc.x + 1 < board_lenx):
                coor1 = Coordinate(self.loc.x+1,self.loc.y+2)
                p = board.grab_piece(coor1)
                if(p.color != self.color):
                    valid_moves.append(self.loc.AccCoord() + coor1.AccCoord())


        return valid_moves

class Rook(Piece):
    def __init__(self,loc,col):
        super().__init__(loc,col)
        self.rep = 'r'
        self.value = 5

    #Generates all valid moves of the rook piece
    def generate_valid_moves(self,board):
        board_lenx = len(board.pieces[0])
        board_leny = len(board.pieces)
        valid_moves = []

        #Checks in the -x direction
        distance = 1
        while(self.loc.x - distance >= 0):
            if(board.pieces[self.loc.y][self.loc.x-distance].rep == 'e'):
                valid_moves.append(self.loc.AccCoord() + Coordinate(self.loc.x-distance,self.loc.y).AccCoord())

            else:
                if(board.pieces[self.loc.y][self.loc.x-distance].color != self.color):
                    valid_moves.append(self.loc.AccCoord() + Coordinate(self.loc.x-distance,self.loc.y).AccCoord())
                break

            distance = distance + 1

        #Checks in the +x direction
        distance = 1
        while(self.loc.x + distance < board_lenx):
            if(board.pieces[self.loc.y][self.loc.x+distance].rep == 'e'):
                valid_moves.append(self.loc.AccCoord() + Coordinate(self.loc.x+distance,self.loc.y).AccCoord())

            else:
                if(board.pieces[self.loc.y][self.loc.x+distance].color != self.color):
                    valid_moves.append(self.loc.AccCoord() + Coordinate(self.loc.x+distance,self.loc.y).AccCoord())
                break

            distance = distance + 1

        #Checks in the -y direction
        distance = 1
        while(self.loc.y - distance >= 0):
            if(board.pieces[self.loc.y-distance][self.loc.x].rep == 'e'):
                valid_moves.append(self.loc.AccCoord() + Coordinate(self.loc.x,self.loc.y-distance).AccCoord())

            else:
                if(board.pieces[self.loc.y-distance][self.loc.x].color != self.color):
                    valid_moves.append(self.loc.AccCoord() + Coordinate(self.loc.x,self.loc.y-distance).AccCoord())
                break

            distance = distance + 1

        #Checks in the +y direction
        distance = 1
        while(self.loc.y + distance < board_leny):
            if(board.pieces[self.loc.y+distance][self.loc.x].rep == 'e'):
                valid_moves.append(self.loc.AccCoord() + Coordinate(self.loc.x,self.loc.y+distance).AccCoord())

            else:
                if(board.pieces[self.loc.y+distance][self.loc.x].color != self.color):
                    valid_moves.append(self.loc.AccCoord() + Coordinate(self.loc.x,self.loc.y+distance).AccCoord())
                break

            distance = distance + 1

        return valid_moves

class Bishop(Piece):
    def __init__(self,loc,col):
        super().__init__(loc,col)
        self.rep = 'b'
        self.value = 3

    #Generates all valid moves of the bishop piece
    def generate_valid_moves(self,board):
        board_lenx = len(board.pieces[0])
        board_leny = len(board.pieces)
        valid_moves = []

        #Checks up and to the right
        distance = 1
        while(self.loc.y+distance < board_leny and self.loc.x+distance < board_lenx):
            if(board.pieces[self.loc.y+distance][self.loc.x+distance].rep == 'e'):
                valid_moves.append(self.loc.AccCoord() + Coordinate(self.loc.x+distance,self.loc.y+distance).AccCoord())

            else:
                if(board.pieces[self.loc.y+distance][self.loc.x+distance].color != self.color):
                    valid_moves.append(self.loc.AccCoord() + Coordinate(self.loc.x+distance,self.loc.y+distance).AccCoord())
                break
            
            distance = distance + 1

        #Checks up and to the left
        distance = 1
        while(self.loc.y+distance < board_leny and self.loc.x-distance >= 0):
            if(board.pieces[self.loc.y+distance][self.loc.x-distance].rep == 'e'):
                valid_moves.append(self.loc.AccCoord() + Coordinate(self.loc.x-distance,self.loc.y+distance).AccCoord())

            else:
                if(board.pieces[self.loc.y+distance][self.loc.x-distance].color != self.color):
                    valid_moves.append(self.loc.AccCoord() + Coordinate(self.loc.x-distance,self.loc.y+distance).AccCoord())
                break
            
            distance = distance + 1

        #Checks down and to the right
        distance = 1
        while(self.loc.y-distance >=0 and self.loc.x+distance < board_lenx):
            if(board.pieces[self.loc.y-distance][self.loc.x+distance].rep == 'e'):
                valid_moves.append(self.loc.AccCoord() + Coordinate(self.loc.x+distance,self.loc.y-distance).AccCoord())

            else:
                if(board.pieces[self.loc.y-distance][self.loc.x+distance].color != self.color):
                    valid_moves.append(self.loc.AccCoord() + Coordinate(self.loc.x+distance,self.loc.y-distance).AccCoord())
                break
            
            distance = distance + 1

        #Checks down and to the left
        distance = 1
        while(self.loc.y-distance >= 0 and self.loc.x-distance >= 0):
            if(board.pieces[self.loc.y-distance][self.loc.x-distance].rep == 'e'):
                valid_moves.append(self.loc.AccCoord() + Coordinate(self.loc.x-distance,self.loc.y-distance).AccCoord())

            else:
                if(board.pieces[self.loc.y-distance][self.loc.x-distance].color != self.color):
                    valid_moves.append(self.loc.AccCoord() + Coordinate(self.loc.x-distance,self.loc.y-distance).AccCoord())
                break
            
            distance = distance + 1

        return valid_moves

class Queen(Piece):
    def __init__(self,loc,col):
        super().__init__(loc,col)
        self.rep = 'q'
        self.value = 9

    #Generates all valid moves of the queen piece
    def generate_valid_moves(self,board):
        board_lenx = len(board.pieces[0])
        board_leny = len(board.pieces)
        valid_moves = []

        #Checks in the -x direction
        distance = 1
        while(self.loc.x - distance >= 0):
            if(board.pieces[self.loc.y][self.loc.x-distance].rep == 'e'):
                valid_moves.append(self.loc.AccCoord() + Coordinate(self.loc.x-distance,self.loc.y).AccCoord())

            else:
                if(board.pieces[self.loc.y][self.loc.x-distance].color != self.color):
                    valid_moves.append(self.loc.AccCoord() + Coordinate(self.loc.x-distance,self.loc.y).AccCoord())
                break

            distance = distance + 1

        #Checks in the +x direction
        distance = 1
        while(self.loc.x + distance < board_lenx):
            if(board.pieces[self.loc.y][self.loc.x+distance].rep == 'e'):
                valid_moves.append(self.loc.AccCoord() + Coordinate(self.loc.x+distance,self.loc.y).AccCoord())

            else:
                if(board.pieces[self.loc.y][self.loc.x+distance].color != self.color):
                    valid_moves.append(self.loc.AccCoord() + Coordinate(self.loc.x+distance,self.loc.y).AccCoord())
                break

            distance = distance + 1

        #Checks in the -y direction
        distance = 1
        while(self.loc.y - distance >= 0):
            if(board.pieces[self.loc.y-distance][self.loc.x].rep == 'e'):
                valid_moves.append(self.loc.AccCoord() + Coordinate(self.loc.x,self.loc.y-distance).AccCoord())

            else:
                if(board.pieces[self.loc.y-distance][self.loc.x].color != self.color):
                    valid_moves.append(self.loc.AccCoord() + Coordinate(self.loc.x,self.loc.y-distance).AccCoord())
                break

            distance = distance + 1

        #Checks in the +y direction
        distance = 1
        while(self.loc.y + distance < board_leny):
            if(board.pieces[self.loc.y+distance][self.loc.x].rep == 'e'):
                valid_moves.append(self.loc.AccCoord() + Coordinate(self.loc.x,self.loc.y+distance).AccCoord())

            else:
                if(board.pieces[self.loc.y+distance][self.loc.x].color != self.color):
                    valid_moves.append(self.loc.AccCoord() + Coordinate(self.loc.x,self.loc.y+distance).AccCoord())
                break

            distance = distance + 1

        #Checks up and to the right
        distance = 1
        while(self.loc.y+distance < board_leny and self.loc.x+distance < board_lenx):
            if(board.pieces[self.loc.y+distance][self.loc.x+distance].rep == 'e'):
                valid_moves.append(self.loc.AccCoord() + Coordinate(self.loc.x+distance,self.loc.y+distance).AccCoord())

            else:
                if(board.pieces[self.loc.y+distance][self.loc.x+distance].color != self.color):
                    valid_moves.append(self.loc.AccCoord() + Coordinate(self.loc.x+distance,self.loc.y+distance).AccCoord())
                break
            
            distance = distance + 1

        #Checks up and to the left
        distance = 1
        while(self.loc.y+distance < board_leny and self.loc.x-distance >= 0):
            if(board.pieces[self.loc.y+distance][self.loc.x-distance].rep == 'e'):
                valid_moves.append(self.loc.AccCoord() + Coordinate(self.loc.x-distance,self.loc.y+distance).AccCoord())

            else:
                if(board.pieces[self.loc.y+distance][self.loc.x-distance].color != self.color):
                    valid_moves.append(self.loc.AccCoord() + Coordinate(self.loc.x-distance,self.loc.y+distance).AccCoord())
                break
            
            distance = distance + 1

        #Checks down and to the right
        distance = 1
        while(self.loc.y-distance >=0 and self.loc.x+distance < board_lenx):
            if(board.pieces[self.loc.y-distance][self.loc.x+distance].rep == 'e'):
                valid_moves.append(self.loc.AccCoord() + Coordinate(self.loc.x+distance,self.loc.y-distance).AccCoord())

            else:
                if(board.pieces[self.loc.y-distance][self.loc.x+distance].color != self.color):
                    valid_moves.append(self.loc.AccCoord() + Coordinate(self.loc.x+distance,self.loc.y-distance).AccCoord())
                break
            
            distance = distance + 1

        #Checks down and to the left
        distance = 1
        while(self.loc.y-distance >= 0 and self.loc.x-distance >= 0):
            if(board.pieces[self.loc.y-distance][self.loc.x-distance].rep == 'e'):
                valid_moves.append(self.loc.AccCoord() + Coordinate(self.loc.x-distance,self.loc.y-distance).AccCoord())

            else:
                if(board.pieces[self.loc.y-distance][self.loc.x-distance].color != self.color):
                    valid_moves.append(self.loc.AccCoord() + Coordinate(self.loc.x-distance,self.loc.y-distance).AccCoord())
                break
            
            distance = distance + 1

        return valid_moves

class King(Piece):
    def __init__(self,loc,col):
        super().__init__(loc,col)
        self.rep = 'k'
        self.value = 1000

    #Generates all valid moves of the king piece, except for castling
    def generate_valid_moves(self,board):
        board_lenx = len(board.pieces[0])
        board_leny = len(board.pieces)
        valid_moves = []

        #Checks to the left, upper left, and lower left of king
        if(self.loc.x-1 >= 0):
            if(board.pieces[self.loc.y][self.loc.x-1].color != self.color):
                valid_moves.append(self.loc.AccCoord() + Coordinate(self.loc.x-1,self.loc.y).AccCoord())
            
            if(self.loc.y-1 >= 0):
                if(board.pieces[self.loc.y-1][self.loc.x-1].color != self.color):
                    valid_moves.append(self.loc.AccCoord() + Coordinate(self.loc.x-1,self.loc.y-1).AccCoord())

            if(self.loc.y+1 <board_leny):
                if(board.pieces[self.loc.y+1][self.loc.x-1].color != self.color):
                    valid_moves.append(self.loc.AccCoord() + Coordinate(self.loc.x-1,self.loc.y+1).AccCoord())
        
        #Checks to the right, upper right, and lower right of king
        if(self.loc.x+1 < board_lenx):
            if(board.pieces[self.loc.y][self.loc.x+1].color != self.color):
                valid_moves.append(self.loc.AccCoord() + Coordinate(self.loc.x+1,self.loc.y).AccCoord())
            
            if(self.loc.y-1 >= 0):
                if(board.pieces[self.loc.y-1][self.loc.x+1].color != self.color):
                    valid_moves.append(self.loc.AccCoord() + Coordinate(self.loc.x+1,self.loc.y-1).AccCoord())

            if(self.loc.y+1 < board_leny):
                if(board.pieces[self.loc.y+1][self.loc.x+1].color != self.color):
                    valid_moves.append(self.loc.AccCoord() + Coordinate(self.loc.x+1,self.loc.y+1).AccCoord())

        #Checks below king
        if(self.loc.y-1 >= 0 and board.pieces[self.loc.y-1][self.loc.x]):
            if(board.pieces[self.loc.y-1][self.loc.x].color != self.color):
                valid_moves.append(self.loc.AccCoord() + Coordinate(self.loc.x,self.loc.y-1).AccCoord())

        #Checks above king
        if(self.loc.y+1 < board_leny):
            if(board.pieces[self.loc.y+1][self.loc.x].color != self.color):
                valid_moves.append(self.loc.AccCoord() + Coordinate(self.loc.x,self.loc.y+1).AccCoord())

        return valid_moves

class Empty(Piece):
    def __init__(self,loc,col):
        super().__init__(loc,col)
        self.rep = 'e'
        self.value = 0
    
    #Returns false as there is not piece in space
    def isEmpty(self):
        return 1
    
    def generate_valid_moves(self,board):
        return []

class MockBoard():
    __slots__= ['turn_num','castling','pieces']
    def __init__(self,board_info,tn,cs):
        self.turn_num = tn
        self.castling = cs

        #Pieces is placed in [y][x] order
        self.pieces = []

        #Creates Empty Board if called for
        if(board_info == "Empty"):
            return

        #Converts Fen String into individual pieces and adds them to the pieces list
        for i in range(len(board_info)):

            self.pieces.append([])
            x_cord = 0
            for j in board_info[i]:

                if(j.isnumeric()):
                    for k in range(int(j)):
                        self.pieces[i].append(Empty(Coordinate(x_cord,i),"NULL"))
                        x_cord = x_cord + 1

                elif(j == 'p' or j == 'P'):
                    if(j.isupper()):
                        color = 'w'
                    else:
                        color = 'b'

                    self.pieces[i].append(Pawn(Coordinate(x_cord,i),color))
                    x_cord = x_cord + 1

                elif(j == 'r' or j == 'R'):
                    if(j.isupper()):
                        color = 'w'
                    else:
                        color = 'b'

                    self.pieces[i].append(Rook(Coordinate(x_cord,i),color))
                    x_cord = x_cord + 1

                elif(j == 'b' or j == 'B'):
                    if(j.isupper()):
                        color = 'w'
                    else:
                        color = 'b'

                    self.pieces[i].append(Bishop(Coordinate(x_cord,i),color))
                    x_cord = x_cord + 1

                elif(j == 'n' or j == 'N'):
                    if(j.isupper()):
                        color = 'w'
                    else:
                        color = 'b'

                    self.pieces[i].append(Knight(Coordinate(x_cord,i),color))
                    x_cord = x_cord + 1

                elif(j == 'q' or j == 'Q'):
                    if(j.isupper()):
                        color = 'w'
                    else:
                        color = 'b'

                    self.pieces[i].append(Queen(Coordinate(x_cord,i),color))
                    x_cord = x_cord + 1

                elif(j == 'k' or j == 'K'):
                    if(j.isupper()):
                        color = 'w'
                    else:
                        color = 'b'

                    self.pieces[i].append(King(Coordinate(x_cord,i),color))
                    x_cord = x_cord + 1

    #Returns piece given coordinates
    def grab_piece(self,coor):
        return self.pieces[coor.y][coor.x]

    #Prints board to screen
    def print_board(self):
        for i in reversed(self.pieces):
            for j in i:
                print(j.rep,": ",j.color[0],"  ",end="")
            print()

        return

    #Performs move on board and returns value of piece taken if there is one
    def make_move(self,move,color):
        #Checks if the move is castleing
        #Queenside
        if(move == "0-0-0"):
            if(color == 'w'):
                y = 0
            else:
                y = 7
                
            self.pieces[y][2] = King(Coordinate(y,2),color)
            self.pieces[y][3] = Rook(Coordinate(y,3),color)
            self.pieces[y][4] = Empty(Coordinate(y,4),"NULL")
            self.pieces[y][0] = Empty(Coordinate(y,0),"NULL")
            
            return 0 
                
        #Kingside
        elif (move == "0-0"):
            if(color == 'w'):
                y = 0
            else:
                y = 7
                
            self.pieces[y][6] = King(Coordinate(y,2),color)
            self.pieces[y][5] = Rook(Coordinate(y,3),color)
            self.pieces[y][4] = Empty(Coordinate(y,4),"NULL")
            self.pieces[y][7] = Empty(Coordinate(y,0),"NULL")
        
            return 0
        
        new_x = ord(move[2])-97
        new_y = int(move[3])-1
        old_x = ord(move[0])-97
        old_y = int(move[1])-1

        #Value of piece taken
        taken_v = self.pieces[new_y][new_y].value

        #Returns for a static 'move'
        if(new_x == old_x and new_y == old_y):
            return 0

        #Sets pieces new spot to that piece
        self.pieces[new_y][new_x] = self.pieces[old_y][old_x].deepcopy()
        self.pieces[new_y][new_x].loc.x = new_x
        self.pieces[new_y][new_x].loc.y = new_y

        #Sets pieces old spot to empty and null
        self.pieces[old_y][old_x] = Empty(Coordinate(old_x,old_y),"NULL")

        #Returns Point Value of Piece Taken
        return taken_v

    #Returns true if king would live after move
    def king_lives(self, move):
        board = self.deepcopy()

        player_color = board.pieces[int(move[1])-1][ord(move[0])-97].color

        #Sets pieces new spot
        board.make_move(move,player_color)

        #print("Color: ",player_color," - Move: ",move)
        #board.print_board()

        #Finds King
        king_found = 0
        for i in board.pieces:
            for j in i:
                if(player_color == j.color and j.rep == 'k'):
                    king = j
                    king_found = 1

        if(not king_found):
            king = board.pieces[int(move[3])-1][ord(move[2])-97]

        #Finds opponent color
        if(player_color == 'w'):
            opp_color = 'b'
        else:
            opp_color = 'w'

        #Identifies opponents moves
        
        opp_moves = []
        for i in board.pieces:
            for j in i:
                if(j.color == opp_color):
                    opp_moves.extend(j.generate_valid_moves(board))

        #Checks to see if opponents moves kill the king
        for i in opp_moves:
            if(king.loc.AccCoord() == i[2:4]):
                return 0
        

        return 1

    #Returns Valid Castle Moves for the given color
    def castle(self,color):
        # 0-0 = King, 0-0-0 = Queen
        moves = []
        check = []

        #Selects correct side of board to check based on color
        if(color == 'b'):
            y = 7
        else:
            y = 0

        #Checks queenside castle
        if(self.pieces[y][4].rep == 'k' and self.pieces[y][0].rep == 'r' and self.pieces[y][1].rep == 'e' and self.pieces[y][2].rep == 'e' and self.pieces[y][3].rep == 'e'):
            check.append(["e8e8","e8d8","e8c8","0-0-0"])

        #Checks kingside castle
        elif(self.pieces[y][4].rep == 'k' and self.pieces[y][7].rep == 'r' and self.pieces[y][5].rep == 'e' and self.pieces[y][6].rep == 'e'):
            check.append(["e8e8","e8f8","e8g8","0-0"])
        
        #Checks all spots of king for castle. Then appends if valid
        king_lived = 1
        for i in check:
            for j in range(3):
                if(not self.king_lives(i[j])):
                    king_lived = 0

            if(king_lived):
                moves.append(i[3])

        return moves

    #Returns a deep copy of the board
    def deepcopy(self):
        new_board = MockBoard("Empty",self.turn_num,self.castling)
        for i in range(8):
            new_board.pieces.append([])
            for j in range(8):
                new_board.pieces[i].append(self.pieces[i][j].deepcopy())

        return new_board
    
    #
    #Determines the hueristic value of the current board
    #Value of all players pieces - value of all opponent pieces
    #
    def Heuristic(self,color):
        value = 0
        for i in self.pieces:
            for j in i:
                if(j.color == color):
                    #Lower value of friendly pieces to incentivize aggression
                    value = value + j.value
                elif(j.color != "NULL"):
                    value = value - j.value
                    
        return value