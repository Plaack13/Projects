
from joueur.base_ai import BaseAI
from games.chess.board_state import MockBoard, Empty, Coordinate
from random import choice, seed
import time


class AI(BaseAI):
    """ The AI you add and improve code inside to play Chess. """

    @property
    def game(self) -> 'games.chess.game.Game':
        """games.chess.game.Game: The reference to the Game instance this AI is playing.
        """
        return self._game 

    @property
    def player(self) -> 'games.chess.player.Player':
        """games.chess.player.Player: The reference to the Player this AI controls in the Game.
        """
        return self._player # 

    def get_name(self) -> str:
        """This is the name you send to the server so your AI will control the player named this string.

        Returns:
            str: The name of your Player.
        """

        return "Chess Player Peyton" # REPLACE THIS WITH YOUR TEAM NAME


    def start(self) -> None:
        """This is called once the game starts and your AI knows its player and game. You can initialize your AI here.
        """


    def game_updated(self) -> None:
        """This is called every time the game's state updates, so if you are tracking anything you can update it here.
        """

    def end(self, won: bool, reason: str) -> None:
        """This is called when the game ends, you can clean up your data and dump files here if need be.

        Args:
            won (bool): True means you won, False means you lost.
            reason (str): The human readable string explaining why your AI won or lost.
        """

    def make_move(self) -> str:
        """This is called every time it is this AI.player's turn to make a move.

        Returns:
            str: A string in Universal Chess Inferface (UCI) or Standard Algebraic Notation (SAN) formatting for the move you want to make. If the move is invalid or not properly formatted you will lose the game.
        """
        print(self.game.print())


        #Grabs info from fen to implement into a board with every piece located on it
        game_info = self.game.fen.split()
        board_info = game_info[0].split("/")
        board_info.reverse()
        game_board = MockBoard(board_info,game_info[-1],game_info[-4])

        #
        #Time Based Itterative Deepening Choice w/ Quiescence Search
        #
        depth = 1
        time_limit = False
        while(not time_limit):
            initial_time = time.time()

            #Select Valid Move For Given Depth
            selected_move = self.Max_Choice(game_board.deepcopy(), depth)
            
            time_to_run = time.time() - initial_time

            #Checks if it should itterate deeper given time taken on current depth
            if(self.time_hueristic(time_to_run)):
                depth = depth + 1
            else:
                time_limit = True
                print(f"Average Depth: {depth}")
                print(f"Time To Run: {time_to_run}")

        selected_move = self.Max_Choice(game_board,depth)
    
        #Checks if pawn is promoted and thus promotes it
        if(selected_move[0] != '0'):
            if(game_board.pieces[int(selected_move[1])-1][ord(selected_move[0])-97].rep == 'p' and
            (int(selected_move[3])-1 == 8 or int(selected_move[3])-1 == 0)):
                selected_move = selected_move + 'q'

        print(f"Selected Move: {selected_move}")

        return selected_move


    # if you need additional functions for your AI you can add them here

    #Returns Opponents Color
    def Oppponent_Color(self):
        if(self.player.color[0] == 'w'):
            return 'b'
        return 'w'
    
    #Generates Valid Moves for color given a game board
    def Generate_Moves(self,game_board,color):
        moves = []
        
        #Generates all non-castleing Valid Moves for pieces
        for i in game_board.pieces:
            for j in i:
                if(j.color == color):
                    gen_moves = j.generate_valid_moves(game_board)
                    for k in gen_moves:
                        if(game_board.king_lives(k)):
                            moves.append(k)
                            
        #Generates Castling Moves
        moves.extend(game_board.castle(color))

        return moves

    #Selects the Move with the largest Hueristic Value
    def Max_Choice(self,game_board,depth):
        moves = []

        #Effectively infinity for alpha and beta
        alpha = -10000
        beta = 10000

        for move in self.Generate_Moves(game_board,self.player.color[0]):
            minimum = self.Min_Value(game_board.deepcopy(),move,depth,alpha,beta)
            moves.append((minimum,move))
        
        #Selects a random move of the highest heuristic values
        #print(moves)
        max_value = max(moves)
        #print(max_value)
        high_moves = []
        for i in moves:
            if(i[0] == max_value[0]):
                high_moves.append(i[1])

        return choice(high_moves)
    
    #Returns Min Hueristic Value of moves given board state

    def Min_Value(self,game_board,move,depth,alpha,beta):
        opp_color = self.Oppponent_Color()
        game_board.make_move(move,opp_color)

        if(depth <= 0):
            return game_board.Heuristic(self.player.color[0])
        
        #Effectively Infinity
        point = 10000
        
        for move in self.Generate_Moves(game_board,opp_color):
            #If a good piece of max is taken then we speed up the depth as the route is less likely to be good
            depth_change = 1
            if(self.quiescence(game_board, move)):
                depth_change = 2

            maximum = self.Max_Value(game_board.deepcopy(),move,depth-depth_change,alpha,beta)
            point = min(point,maximum)
            if(point <= alpha):
                return point
            beta = min(beta,point)
        
        return point
    
    #Returns Max Huersistic Value of moves given board state
    def Max_Value(self,game_board,move,depth,alpha,beta):
        game_board.make_move(move,self.player.color[0])
        
        if(depth <= 0):
            return game_board.Heuristic(self.player.color[0])
        #Effectively Negative Infinity
        point = -10000
        
        for move in self.Generate_Moves(game_board,self.player.color[0]):
            #If a good piece of min is taken we extend the depth as the route is more likely to be good
            depth_change = 1
            if(self.quiescence(game_board,move)):
                depth_change = 0

            minimum = self.Min_Value(game_board.deepcopy(),move,depth-depth_change,alpha,beta)
            point = max(point,minimum)
            if(point >= beta):
                return point
            alpha = max(alpha,point)
        
        return point

    #Returns if algorithm should run to a further depth
    #If the time of the last run depth is multiplied by the time factor
    #And comes out to greater than 10 then it should not be run to a lower depth
    def time_hueristic(self,time_to_run):
        #Average effect of adding another depth limit
        TIME_FACTOR = 24.60386569
        
        #Decreased Time in Time Hueristic Due to increased time of quiescence
        if(time_to_run * TIME_FACTOR > 6):
            return False
        return True

    #Defines Quiescence search
    #If the move causes the player to take a more valuable piece then the depth searched is further
    #If the value of a piece taken is 3 or more then the depth is not subtracted allowing it to go deeper
    def quiescence(self,board,move):
        #Any move that is not describe in lenght four is worth exploring
        #Pawn upgrade, castling, etc.
        if(len(move) != 4):
            return 1

        taken_x = ord(move[2])-97
        taken_y = int(move[3])-1

        if(board.pieces[taken_y][taken_x].value >= 3):
            return True

        return False