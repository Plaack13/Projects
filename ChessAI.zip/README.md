#################################
#       Compiling & Running	#
#################################

You have been provided a bash script called `play.sh`, which compiles and runs your code; it also starts a game session between your AI and itself. DO NOT MODIFY THIS SCRIPT.
You can run `play.sh` using the following command format :

	./play.sh Joueur.<lang> Session_ID

Where `Joueur.<lang>` is the directory for the language you are coding in. An example of the above command for c++ would be :

	./play.sh Joueur.cpp AIisAwesome
