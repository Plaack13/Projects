# Using SQLite for the database
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
import sqlite3
import spotipy
import spotipy.util as util
from spotipy.oauth2 import SpotifyOAuth

import random
import sys

#Creating Global Variables
cid = '1f01fd5302a24752956e07bc472e0976'
secret = '72ec6ba60c2f4fc9ba135dadaf5f5d24'

#Creates the structure for the SQLite database

def create_database():
  #connects to SweetJimmyJams database (or creates it if none exists)
  conn = sqlite3.connect('SweetJimmyJams.db')

  #creats cursor to interact with SweetJimmyJams.db
  c = conn.cursor()

  #Creates all the appropriate tables for SweetJimmyJams.db if they do not exist already

  c.execute('''
  CREATE TABLE IF NOT EXISTS Artist(
  AR_ID TEXT PRIMARY KEY,
  Artist_Name TEXT NOT NULL
  )
  ''')

  c.execute('''
  CREATE TABLE IF NOT EXISTS Genre(
  Subgenre TEXT,
  AR_ID REFERENCES Artist(AR_ID)
  )
  ''')

  c.execute('''
  CREATE TABLE IF NOT EXISTS Album(
  AL_ID TEXT PRIMARY KEY,
  Album_Name TEXT NOT NULL,
  AR_ID REFERENCES Artist(AR_ID)
  )
  ''')

  c.execute('''
  CREATE TABLE IF NOT EXISTS User(
  Username TEXT PRIMARY KEY,
  Password TEXT NOT NULL,
  F_Name TEXT,
  L_Name TEXT,
  Email TEXT
  )
  ''')

  c.execute('''
  CREATE TABLE IF NOT EXISTS Song(
  S_ID TEXT PRIMARY KEY,
  Song_Name TEXT NOT NULL,
  Popularity INTEGER,
  AL_ID REFERENCES Album(AL_ID) NOT NULL
  )
  ''')

  c.execute('''
  CREATE TABLE IF NOT EXISTS Playlist(
  PL_ID TEXT PRIMARY KEY,
  Username REFERENCES User(Username) NOT NULL,
  Playlist_Title TEXT NOT NULL
  )
  ''')

  c.execute('''
  CREATE TABLE IF NOT EXISTS Song_in_Playlist(
  S_ID REFERENCES Song(S_ID),
  PL_ID REFERENCES Playlist(PL_ID)
  )
  ''')

  #commits info to database
  conn.commit()

  #disconnects from database
  conn.close()




#UI Implementation
#Window contains information related to an information error
class InfoErrorWindow(QWidget):
  def __init__(self):
    super().__init__()

    self.setWindowTitle("ERROR - Information")

    #Sets up info of error type
    self.label = QLabel("Error - Information Incorrect")
    font_L = self.label.font()
    font_L.setPointSize(25)
    self.label.setFont(font_L)
    self.label.setAlignment(Qt.AlignHCenter)

    #Sets up info of error fix
    self.label2 = QLabel("Either the information submitted does not exist, or it is incorrect")
    font_s = self.label2.font()
    font_s.setPointSize(15)
    self.label2.setFont(font_s)
    self.label2.setAlignment(Qt.AlignHCenter)

    #Combines Titles
    layout = QVBoxLayout()
    layout.addWidget(self.label)
    layout.addWidget(self.label2)
    self.setLayout(layout)





#Window contains user information that can be changed
class UserSettingsWindow(QWidget):
  def __init__(self):
    super().__init__()

    self.setWindowTitle("Settings")

    #Connects to database to receive data
    conn = sqlite3.connect("SweetJimmyJams.db")
    c = conn.cursor()

    #Defines title of window
    self.title = QLabel ("User Settings")
    font_L = self.title.font()
    font_L.setPointSize(25)
    self.title.setFont(font_L)

    #Grabs relevant current user information
    id_search = c.execute("SELECT F_Name, L_Name, Email FROM User WHERE Username = ?",(current_username,))
    list1 = c.fetchall()
    current_f_name = list1[0][0]
    current_l_name = list1[0][1]
    current_email = list1[0][2]
    
    #Defines F_Name text
    self.f_name = QLabel("First Name: " + current_f_name)
    font_M = self.f_name.font()
    font_M.setPointSize(20)
    self.f_name.setFont(font_M)

    #Defines F_Name input
    self.f_name_input = QLineEdit()
    self.f_name_input.setFont(font_M)
    self.f_name_input.setPlaceholderText("Enter New First Name:")

    #Defines L_Name text 
    self.l_name = QLabel("Last Name: " + current_l_name)
    self.l_name.setFont(font_M)

    #Defines F_Name input
    self.l_name_input = QLineEdit()
    self.l_name_input.setFont(font_M)
    self.l_name_input.setPlaceholderText("Enter New Last Name:")

    #Defines Email text
    self.email = QLabel("Email: " + current_email)
    self.email.setFont(font_M)
    
    #Defines F_Name input
    self.email_input = QLineEdit()
    self.email_input.setFont(font_M)
    self.email_input.setPlaceholderText("Enter New Email:")

    #Defines Submit button
    self.submit = QPushButton("Submit")
    self.submit.setFont(font_M)
    self.submit.clicked.connect(self.new_settings)

    #Defines Widget Layout
    layout = QVBoxLayout()

    #Combines Widgets
    layout.addWidget(self.title)
    layout.addWidget(self.f_name)
    layout.addWidget(self.f_name_input)
    layout.addWidget(self.l_name)
    layout.addWidget(self.l_name_input)
    layout.addWidget(self.email)
    layout.addWidget(self.email_input)
    layout.addWidget(self.submit)

    self.setLayout(layout)

    conn.commit()
    conn.close()

  def new_settings(self):
    conn2 = sqlite3.connect("SweetJimmyJams.db")
    d = conn2.cursor()

    if(self.f_name_input.displayText() != ""):
      d.execute("UPDATE User SET F_Name = ? WHERE Username = ?",(self.f_name_input.displayText(),current_username))

    if(self.f_name_input.displayText() != ""):
      d.execute("UPDATE User SET L_Name = ? WHERE Username = ?",(self.l_name_input.displayText(),current_username))

    if(self.f_name_input.displayText() != ""):
      d.execute("UPDATE User SET Email = ? WHERE Username = ?",(self.email_input.displayText(),current_username))

    conn2.commit()
    conn2.close()

    self.close()
    return







class GenerateArtistWindow(QWidget):
  def __init__(self):
    super().__init__()

    self.setWindowTitle("Artist Generation!")

    #Sets up title of window
    self.title = QLabel("Generate a Preferred Artist")
    font_L = self.title.font()
    font_L.setPointSize(25)
    self.title.setFont(font_L)

    #Sets up artist pop title
    self.popularity = QLabel("Select Artist Popularity")
    font_s = self.popularity.font()
    font_s.setPointSize(15)
    self.popularity.setFont(font_s)

    #Creates a drop down button to select artist popularity
    self.drop_pop = QComboBox()
    self.font_M = self.drop_pop.font()
    self.font_M.setPointSize(20)
    self.drop_pop.setFont(self.font_M)
    for i in range(1,11):
      self.drop_pop.addItem(str(i))

    #Sets up playlist choice title
    self.playlist = QLabel("Select a Playlist to Generate Based On")
    self.playlist.setFont(self.font_M)

    #Creates a drop down button to select playlist
    self.drop_playlist = QComboBox()
    self.drop_playlist.setFont(self.font_M)
    current_playlists = self.grab_playlists()
    for i in current_playlists:
      self.drop_playlist.addItem(i[1])

    #Creates generate button
    self.generate = QPushButton("Generate!")
    self.generate.setFont(self.font_M)
    self.generate.clicked.connect(self.generate_artist_name)

    #Defines Widget Layout
    self.layout = QVBoxLayout()

    #Combines Widgets
    self.layout.addWidget(self.title)
    self.layout.addWidget(self.popularity)
    self.layout.addWidget(self.drop_pop)
    self.layout.addWidget(self.playlist)
    self.layout.addWidget(self.drop_playlist)
    self.layout.addWidget(self.generate)

    self.setLayout(self.layout)

  #Retrieves playlist information related to current user
  def grab_playlists(self):
    conn = sqlite3.connect("SweetJimmyJams.db")
    c = conn.cursor()

    c.execute("SELECT PL_ID, Playlist_Title FROM Playlist WHERE Username = ?",(current_username,))
    playlists = c.fetchall()

    conn.commit()
    conn.close()

    return playlists

  #Generates name of artist based on chosen playlist and preferred popularity
  def generate_artist_name(self):
    popularity = self.drop_pop.currentText()
    list_of_playlists = self.grab_playlists()

    temp_artist_name = "Des Rocs"
    conn = sqlite3.connect("SweetJimmyJams.db")
    c = conn.cursor()

    if(list_of_playlists == []):
      self.t = InfoErrorWindow()
      self.t.show()

    else:
      playlist_id = list_of_playlists[self.drop_playlist.currentIndex()][0]

      c.execute('''
      WITH song_list as(
      SELECT *
      FROM Song_in_Playlist
      WHERE PL_ID = ? 
      ),

      song_info as(
      SELECT *
      FROM song_list
      JOIN Song
      WHERE song_list.S_ID = Song.S_ID
      ),

      al_info as(
      SELECT *
      FROM song_info
      JOIN Album
      WHERE song_info.AL_ID = Album.AL_ID
      )

      SELECT DISTINCT AR_ID
      FROM al_info
      ''',(playlist_id,))

      artists = c.fetchall()

      
      #Selects random artist from chosen playlist
      select_artist = artists[random.randrange(len(artists))]

      
      scope = "playlist-read-private"
      token = util.prompt_for_user_token(username = current_username, scope = scope, client_id=cid,client_secret=secret, redirect_uri = "https;//localhost:10")
      sp = spotipy.Spotify(auth=token)

      #Retrieves information on artists related to randomly selected artist
      related_artists = sp.artist_related_artists(select_artist[0])
      related_artists = related_artists['artists']
      thinned_artists = []

      #Thins set of artists to only relevent terms
      for i in related_artists:
        thinned_artists.append([i['popularity'],i['name']])

      #Sorts generated artists by popularity
      thinned_artists.sort()

      #Adds Name of recommended artist to the bottom of the window based on popularity
      if(thinned_artists != []):
        self.new_artist = QLabel(thinned_artists[(int(popularity)-1) * 2 + random.randrange(2)][1])
        self.new_artist.setFont(self.font_M)
        self.layout.addWidget(self.new_artist)

        self.setLayout(self.layout)

    conn.commit()
    conn.close()





#Window displays information related to users playlists
#Information can be displayed based on user preferences
class ReviewPlaylistWindow(QWidget):
  def __init__(self):
    super().__init__()

    self.setWindowTitle("Review Playlist")

    #Sets up title of Window
    self.title = QLabel("Review Playlist")
    font_L = self.title.font()
    font_L.setPointSize(25)
    self.font_s = self.title.font()  #Sets up font for later use
    self.font_s.setPointSize(15)
    self.title.setFont(font_L)

    #Sort Method Drop Down
    self.sort_by = QComboBox()
    font_M = self.sort_by.font()
    font_M.setPointSize(20)
    self.sort_by.setFont(font_M)
    self.sort_by.addItems(["Song Name","Artist Name","Album Name","Popularity"])
    
    #Sets up drop down button to select playlist
    self.drop_playlist = QComboBox()
    self.drop_playlist.setFont(font_M)

    #Retrieves user playlists and adds them to drop playlist button
    self.user_playlists = self.grab_playlists()
    for i in self.user_playlists:
      self.drop_playlist.addItem(i[1])

    #Sets up Favorite Genre Button
    self.fav_genre = QPushButton("          Favorite Genre          ")
    self.fav_genre.setFont(font_M)

    #Sets up Favorite Artist Button
    self.fav_artist = QPushButton("          Favorite Artist          ")
    self.fav_artist.setFont(font_M)

    #Sets up Favorite Album Button
    self.fav_album = QPushButton("          Favorite Album          ")
    self.fav_album.setFont(font_M)

    #Sets up blank label to make the UI look cleaner
    self.blank = QLabel("")
    self.blank.setFont(font_M)

    #Set up area for Favorite to print
    self.fav_print = QLabel("")
    self.fav_print.setFont(font_M)

    #Sets up scroll area info
    self.scroll_info = QLabel("Song Name by: Artist Name on: Album Name | Popularity (0 - 100, low to high)")
    self.scroll_info.setFont(self.font_s)

    #Setting up scrollable area
    self.scroll = QScrollArea()
    self.info = QWidget()
    self.temp_layout = QVBoxLayout()

    #Grabs all important playlist info
    self.playlist_attributes = self.retrieve_playlist_attributes()

    #Formats important playlist attributes and places them in a layout   
    for i in self.playlist_attributes: 
      song_information = i[0] + " by: " + i[1] + " on: " + i[2] + " |  Popularity: " + str(i[3]) 
      song_information_label = QLabel(song_information)
      song_information_label.setFont(self.font_s)
      self.temp_layout.addWidget(song_information_label)
    
    #Places song info in scroll area and defines the scroll area
    self.info.setLayout(self.temp_layout)
    self.scroll.setWidgetResizable(True)
    self.scroll.setWidget(self.info)

    
    #Setting up Layout
    self.left_layout = QVBoxLayout()
    self.right_layout = QVBoxLayout()
    self.drop_layout = QHBoxLayout()
    self.Final_layout = QHBoxLayout()

    #Establishes connections to widgets
    self.drop_playlist.currentIndexChanged.connect(self.update_scroll_area)
    self.sort_by.currentIndexChanged.connect(self.update_scroll_area)
    self.fav_artist.clicked.connect(self.find_fav_artist)
    self.fav_album.clicked.connect(self.find_fav_album)
    self.fav_genre.clicked.connect(self.find_fav_genre)

    #Adds Widgets
    self.drop_layout.addWidget(self.drop_playlist)
    self.drop_layout.addWidget(self.sort_by)

    self.left_layout.addWidget(self.title)
    self.left_layout.addLayout(self.drop_layout)
    self.left_layout.addWidget(self.scroll_info)
    self.left_layout.addWidget(self.scroll)

    self.right_layout.addWidget(self.blank)
    self.right_layout.addWidget(self.fav_artist)
    self.right_layout.addWidget(self.fav_album)
    self.right_layout.addWidget(self.fav_genre)
    self.right_layout.addWidget(self.fav_print)

    self.Final_layout.addLayout(self.left_layout)
    self.Final_layout.addLayout(self.right_layout)

    self.setLayout(self.Final_layout)

  #Returns playlists connected to current user
  def grab_playlists(self):
    conn = sqlite3.connect("SweetJimmyJams.db")
    c = conn.cursor()

    c.execute("SELECT PL_ID,Playlist_Title FROM Playlist WHERE Username = ?",(current_username,))
    playlists = c.fetchall()

    conn.commit()
    conn.close()

    return playlists

  #Returns list of the playlist attributes, Song_Name, Artist_Name, Album_Name, and Popularity in
  #order selected by user from the sort_by drop down function
  def retrieve_playlist_attributes(self):
    conn = sqlite3.connect("SweetJimmyJams.db")
    c = conn.cursor()

    playlist_id = self.user_playlists[self.drop_playlist.currentIndex()][0]


    #I only split the c.execute statements into multiple elif statements because
    #the ORDER BY function was not accepting variables
    #Query for Playlist info sorted by song name
    if(self.sort_by.currentIndex() == 0):
      c.execute('''
      WITH song_list as(
      SELECT *
      FROM Song_in_Playlist
      WHERE PL_ID = ?
      ),

      song_info as(
      SELECT *
      FROM Song_list
      JOIN Song
      WHERE song_list.S_ID = Song.S_ID
      ),
      
      al_info as(
      SELECT *
      FROM song_info
      JOIN Album
      WHERE song_info.AL_ID = Album.AL_ID
      ),

      ar_info as(
      SELECT *
      FROM al_info
      JOIN Artist
      WHERE al_info.AR_ID = Artist.AR_ID
      )

      SELECT DISTINCT Song_Name, Artist_Name, Album_Name, Popularity
      FROM ar_info
      ORDER BY Song_Name
      ''',(playlist_id,))

    #Query for Playlist info sorted by artist name
    elif(self.sort_by.currentIndex() == 1):
      c.execute('''
      WITH song_list as(
      SELECT *
      FROM Song_in_Playlist
      WHERE PL_ID = ?
      ),

      song_info as(
      SELECT *
      FROM Song_list
      JOIN Song
      WHERE song_list.S_ID = Song.S_ID
      ),
      
      al_info as(
      SELECT *
      FROM song_info
      JOIN Album
      WHERE song_info.AL_ID = Album.AL_ID
      ),

      ar_info as(
      SELECT *
      FROM al_info
      JOIN Artist
      WHERE al_info.AR_ID = Artist.AR_ID
      )

      SELECT DISTINCT Song_Name, Artist_Name, Album_Name, Popularity
      FROM ar_info
      ORDER BY Artist_Name
      ''',(playlist_id,))

    #Query for Playlist info sorted by album name
    elif(self.sort_by.currentIndex() == 2):
      c.execute('''
      WITH song_list as(
      SELECT *
      FROM Song_in_Playlist
      WHERE PL_ID = ?
      ),

      song_info as(
      SELECT *
      FROM Song_list
      JOIN Song
      WHERE song_list.S_ID = Song.S_ID
      ),
      
      al_info as(
      SELECT *
      FROM song_info
      JOIN Album
      WHERE song_info.AL_ID = Album.AL_ID
      ),

      ar_info as(
      SELECT *
      FROM al_info
      JOIN Artist
      WHERE al_info.AR_ID = Artist.AR_ID
      )

      SELECT DISTINCT Song_Name, Artist_Name, Album_Name, Popularity
      FROM ar_info
      ORDER BY Album_Name
      ''',(playlist_id,))

    #Query for Playlist info sorted by popularity
    else:
      c.execute('''
      WITH song_list as(
      SELECT *
      FROM Song_in_Playlist
      WHERE PL_ID = ?
      ),

      song_info as(
      SELECT *
      FROM Song_list
      JOIN Song
      WHERE song_list.S_ID = Song.S_ID
      ),
      
      al_info as(
      SELECT *
      FROM song_info
      JOIN Album
      WHERE song_info.AL_ID = Album.AL_ID
      ),

      ar_info as(
      SELECT *
      FROM al_info
      JOIN Artist
      WHERE al_info.AR_ID = Artist.AR_ID
      )

      SELECT DISTINCT Song_Name, Artist_Name, Album_Name, Popularity
      FROM ar_info
      ORDER BY Popularity DESC
      ''',(playlist_id,))

    playlist_attributes = c.fetchall()
    
    conn.commit()
    conn.close()

    return playlist_attributes

  #Updates the scroll area based on current conditions of drop down boxes 
  def update_scroll_area(self):
    play_att = self.retrieve_playlist_attributes()
    t_layout = QVBoxLayout()
    temp = QWidget()

    for i in play_att: 
      song_information = i[0] + " by: " + i[1] + " on: " + i[2] + " |  Popularity: " + str(i[3]) 
      song_information_label = QLabel(song_information)
      song_information_label.setFont(self.font_s)
      t_layout.addWidget(song_information_label)

    temp.setLayout(t_layout)
    self.scroll.setWidget(temp)

  #Queries for users favorite artist in playlist and then updates fav_print with that information
  def find_fav_artist(self):
    conn = sqlite3.connect("SweetJimmyJams.db")
    c = conn.cursor()

    playlist_id = self.user_playlists[self.drop_playlist.currentIndex()][0]

    c.execute('''
    WITH song_list as(
    SELECT *
    FROM Song_in_Playlist
    WHERE PL_ID = ?
    ),

    song_info as(
    SELECT *
    FROM Song_list
    JOIN Song
    WHERE song_list.S_ID = Song.S_ID
    ),
    
    al_info as(
    SELECT *
    FROM song_info
    JOIN Album
    WHERE song_info.AL_ID = Album.AL_ID
    ),

    ar_info as(
    SELECT *
    FROM al_info
    JOIN Artist
    WHERE al_info.AR_ID = Artist.AR_ID
    )

    SELECT Artist_Name, 
    COUNT(Artist_Name) as occurs
    FROM ar_info
    GROUP BY Artist_Name
    ORDER BY occurs DESC
    LIMIT 1 
    ''',(playlist_id,))

    favorite = c.fetchall()
    self.fav_print.setText(favorite[0][0])

    conn.commit()
    conn.close

  #Queries for users favorite album in playlist and then updates fav_print with that information
  def find_fav_album(self):
    conn = sqlite3.connect("SweetJimmyJams.db")
    c = conn.cursor()

    playlist_id = self.user_playlists[self.drop_playlist.currentIndex()][0]

    c.execute('''
    WITH song_list as(
    SELECT *
    FROM Song_in_Playlist
    WHERE PL_ID = ?
    ),

    song_info as(
    SELECT *
    FROM Song_list
    JOIN Song
    WHERE song_list.S_ID = Song.S_ID
    ),
    
    al_info as(
    SELECT *
    FROM song_info
    JOIN Album
    WHERE song_info.AL_ID = Album.AL_ID
    ),

    ar_info as(
    SELECT *
    FROM al_info
    JOIN Artist
    WHERE al_info.AR_ID = Artist.AR_ID
    )

    SELECT Album_Name, COUNT(Album_Name) as occurs
    FROM ar_info
    GROUP BY Album_Name
    ORDER BY occurs DESC
    LIMIT 1
    ''',(playlist_id,))

    favorite = c.fetchall()
    self.fav_print.setText(favorite[0][0])

    conn.commit()
    conn.close

  #Queries for users favorite genre in playlist and then updates fav_print with that information
  def find_fav_genre(self):
    conn = sqlite3.connect("SweetJimmyJams.db")
    c = conn.cursor()

    playlist_id = self.user_playlists[self.drop_playlist.currentIndex()][0]

    c.execute('''
    WITH song_list as(
    SELECT *
    FROM Song_in_Playlist
    WHERE PL_ID = ?
    ),

    song_info as(
    SELECT *
    FROM Song_list
    JOIN Song
    WHERE song_list.S_ID = Song.S_ID
    ),
    
    al_info as(
    SELECT *
    FROM song_info
    JOIN Album
    WHERE song_info.AL_ID = Album.AL_ID
    ),

    ar_info as(
    SELECT *
    FROM al_info
    JOIN Artist
    WHERE al_info.AR_ID = Artist.AR_ID
    ),

    genre_info as(
    SELECT *
    FROM ar_info
    JOIN Genre
    WHERE Genre.AR_ID = ar_info.AR_ID
    )

    SELECT Subgenre, 
    COUNT(Subgenre) as occurs
    FROM genre_info
    GROUP BY Subgenre
    ORDER BY occurs DESC
    LIMIT 1
    ''',(playlist_id,))

    favorite = c.fetchall()
    self.fav_print.setText(favorite[0][0])

    conn.commit()
    conn.close
    



    
class DeletePlaylistWindow(QWidget):
  def __init__(self):
    super().__init__()

    self.setWindowTitle("Delete Playlists")

    #Sets up title of window
    self.title = QLabel("Choose Playlist to Delete")
    font_L = self.title.font()
    font_L.setPointSize(25)
    self.title.setFont(font_L)

    #Grabs playlists connected to user
    self.playlists = self.get_playlists()

    #Creates drop down button to select delete-able playlists
    self.drop_down = QComboBox()
    font_M = self.drop_down.font()
    font_M.setPointSize(20)
    self.drop_down.setFont(font_M)
    for i in self.playlists:
      self.drop_down.addItem(i[0])

    #Creates submit button
    self.submit = QPushButton("Submit")
    self.submit.setFont(font_M)
    self.submit.clicked.connect(self.remove_playlist)

    #sets up layout
    layout = QVBoxLayout()

    #Adds Widgets
    layout.addWidget(self.title)
    layout.addWidget(self.drop_down)
    layout.addWidget(self.submit)

    self.setLayout(layout)

  #Returns playlists connected to user
  def get_playlists(self):
    conn = sqlite3.connect("SweetJimmyJams.db")
    c = conn.cursor()

    c.execute("SELECT Playlist_Title, PL_ID FROM Playlist WHERE Username = ?",(current_username,))

    playlists = c.fetchall()

    conn.commit()
    conn.close()

    return playlists

  #Delets selected playlist from database. Along with its references in song_in_playlist
  def remove_playlist(self):
    conn = sqlite3.connect("SweetJimmyJams.db")
    c = conn.cursor()

    playlist_id = self.playlists[self.drop_down.currentIndex()][1]

    c.execute("DELETE FROM Song_in_Playlist WHERE PL_ID = ?",(playlist_id,))
    c.execute("DELETE FROM Playlist WHERE PL_ID = ?",(playlist_id,))

    conn.commit()
    conn.close()

    self.close()







#Window contains title and drop down button to add user playlists to database
class AddPlaylistWindow(QWidget):
  def __init__(self):
    super().__init__()

    self.setWindowTitle("Add Playlists")

    #Sets up title of window
    self.title = QLabel("Choose Playlist to Add!")
    font_L = self.title.font()
    font_L.setPointSize(25)
    self.title.setFont(font_L)

    #Creates a list of user playlists
    playlist_info = self.grab_user_playlists()

    #thins playlist information down to only playlists not already added
    valid_playlist_info = self.valid_playlists(playlist_info)

    #Creates drop down button to select add-able playlists
    self.drop_down = QComboBox()
    font_M = self.drop_down.font()
    font_M.setPointSize(20)
    self.drop_down.setFont(font_M)
    for i in valid_playlist_info:
      self.drop_down.addItems([i[0]])

    #Creates Submit Button to 
    self.submit = QPushButton("Submit")
    self.submit.setFont(font_M)
    self.submit.clicked.connect(lambda: self.add_playlist(valid_playlist_info))
    
    #Creates widget layout
    layout = QVBoxLayout()

    #Adds Widgets
    layout.addWidget(self.title)
    layout.addWidget(self.drop_down)
    layout.addWidget(self.submit)

    self.setLayout(layout)
    
  #Grabs playlist information from Spotify API
  def grab_user_playlists(self):
    scope = "playlist-read-private"
    token = util.prompt_for_user_token(username = current_username, scope = scope, client_id=cid, client_secret=secret, redirect_uri = "http://localhost:10")
    sp = spotipy.Spotify(auth=token)
    user_playlists = sp.current_user_playlists()
    
    playlist_info = []
    for item in user_playlists['items']:
      playlist_info.append([item['name'],item['id'],item['tracks']['total']])

    return playlist_info

  #Thins a list of playlists to only one whose ID's are not in the database
  def valid_playlists(self, playlist_info):
    conn = sqlite3.connect("SweetJimmyJams.db")
    c = conn.cursor()

    valid_playlist_info = []

    for j in playlist_info:
      id_search = c.execute("SELECT PL_ID FROM Playlist WHERE PL_ID = (?)",(j[1],))
      if([] ==  c.fetchall()):
        valid_playlist_info.append(j)

    conn.commit()
    conn.close()

    return valid_playlist_info

  #Adds playlists to the database
  def add_playlist(self,valid_playlist_info):
    conn = sqlite3.connect("SweetJimmyJams.db")
    c = conn.cursor()

    #Connects to spotify's API and retrieves all track information related to selected playlist
    scope = "playlist-read-private"
    token = util.prompt_for_user_token(username = current_username, scope=scope,client_id=cid,client_secret=secret,redirect_uri="http://localhost:10")
    sp = spotipy.Spotify(auth=token)
    num_tracks = valid_playlist_info[self.drop_down.currentIndex()][2]
    tracklist = sp.playlist_tracks(valid_playlist_info[self.drop_down.currentIndex()][1])

    c.execute("INSERT INTO Playlist VALUES (?,?,?)",(valid_playlist_info[self.drop_down.currentIndex()][1],current_username,valid_playlist_info[self.drop_down.currentIndex()][0]))

    #For statement is to repeat insertion process as one can only recieve 100 songs from Spotify at a time
    for i in range(int(num_tracks / 100 + 1)):
      tracklist = sp.playlist_tracks(valid_playlist_info[self.drop_down.currentIndex()][1],None,100,100*i)
      
      for item in tracklist['items']:
        track = item['track']

        #Formats important artist info
        artist = track['artists']
        ar_name = artist[0]['name']
        ar_id = artist[0]['id']

        #Formats important album info
        album = track['album']
        al_id = album['id']
        al_name = album['name']

        #Formats important song info
        song_name = track['name']
        song_id = track['id']
        popularity = track['popularity']

        #Adds Necessary Artists and Genres to form a playlist
        id_search = c.execute("SELECT AR_ID FROM Artist WHERE AR_ID = (?)",(ar_id,))
        if([] == c.fetchall()):
          c.execute("INSERT INTO Artist VALUES (?,?)",(ar_id,ar_name))

          #Adds genre details once an artist is added for the first time
          detailed_artist_info = sp.artist(ar_id)
          genres = detailed_artist_info['genres']
          for i in genres:
            id_search_c = c.execute("SELECT AR_ID, Subgenre FROM Genre WHERE AR_ID = (?) AND Subgenre = (?)",(ar_id,i))
            if([] == c.fetchall()):
              c.execute("INSERT INTO Genre VALUES (?,?)",(i,ar_id))


        #Adds Necessary Albums to form a playlist
        id_search = c.execute("SELECT AL_ID FROM Album WHERE AL_ID = (?)",(al_id,))
        if([] == c.fetchall()):
          c.execute("INSERT INTO Album VALUES (?,?,?)",(al_id,al_name,ar_id))

        #Adds Necessary Songs to form a playlist
        id_search = c.execute("SELECT S_ID FROM Song WHERE S_ID = (?)",(song_id,))
        if([] == c.fetchall()):
          c.execute("INSERT INTO Song VALUES (?,?,?,?)",(song_id,song_name,popularity,al_id))
      
        #Relates Songs and Playlists together
        id_search = c.execute("SELECT PL_ID, S_ID FROM Song_in_Playlist WHERE PL_ID = (?) AND S_ID = (?)",(valid_playlist_info[self.drop_down.currentIndex()][1],song_id))
        if([] == c.fetchall()):
          c.execute("INSERT INTO Song_in_Playlist VALUES (?,?)", (song_id,valid_playlist_info[self.drop_down.currentIndex()][1]))

    conn.commit()
    conn.close()

    self.close()






# Window contains title and buttons leading to the main functions of the program. Requires authorization to access.
class TitleWindow(QWidget):
  def __init__(self):
    super().__init__()

    self.setWindowTitle("Sweet Jimmy Jams")

    #Sets up Title
    self.title = QLabel("Welcome to Sweet Jimmy Jams")
    font_L = self.title.font()
    font_L.setPointSize(25)
    self.title.setFont(font_L)

    #Creates Add_playlist Button
    self.add_playlist = QPushButton("Add Playlists")
    font_M = self.add_playlist.font()
    font_M.setPointSize(20)
    self.add_playlist.setFont(font_M)
    self.add_playlist.clicked.connect(self.add_playlist_window)

    #Creates Delete_playlist Button
    self.delete_playlist = QPushButton("Delete Playlist")
    self.delete_playlist.setFont(font_M)
    self.delete_playlist.clicked.connect(self.delete_playlist_window)

    #Creates Review_playlist Button
    self.review_playlist = QPushButton("Review Playlists")
    self.review_playlist.setFont(font_M)
    self.review_playlist.clicked.connect(self.review_playlist_window)

    #Creates Generate_artists Button
    self.generate_artists = QPushButton("Generate Artists")
    self.generate_artists.setFont(font_M)
    self.generate_artists.clicked.connect(self.generate_artists_window)

    #Displays username
    self.display_username = QLabel(current_username)
    self.setFont(font_M)

    #Creates Settings Button
    self.settings = QPushButton("Settings")
    self.settings.setFont(font_M)
    self.settings.clicked.connect(self.user_settings_window)

    #Creates Switch User Button
    self.switch_user = QPushButton("Switch User")
    self.switch_user.setFont(font_M)
    self.switch_user.clicked.connect(self.close)

    #Creates Blank Title to make the UI cleaner
    self.blank = QLabel ("")
    self.blank.setFont(font_L)
    
    #Defines Widget Layout
    layout = QVBoxLayout()
    layout2 = QVBoxLayout()
    final_layout = QHBoxLayout()

    #Combines Widgets
    layout.addWidget(self.title)
    layout.addWidget(self.blank)
    layout.addWidget(self.add_playlist)
    layout.addWidget(self.delete_playlist)
    layout.addWidget(self.review_playlist)
    layout.addWidget(self.generate_artists)

    layout2.addWidget(self.blank)
    layout2.addWidget(self.display_username)
    layout2.addWidget(self.settings)
    layout2.addWidget(self.switch_user)

    final_layout.addLayout(layout)
    final_layout.addLayout(layout2)

    #Calls Group of Widgets
    self.setLayout(final_layout)

  #Opens instance of AddPlaylistWindow
  def add_playlist_window(self,checked):
    self.t = AddPlaylistWindow()
    self.t.show()

  #Opens instance of DeletePlaylistWindow
  def delete_playlist_window(self,checked):
    self.t = DeletePlaylistWindow()
    self.t.show()

  #Opens instance of ReviewPLaylistWindow
  def review_playlist_window(self,checked):
    self.t = ReviewPlaylistWindow()
    self.t.show()

  #Opens instance of GenerateArtistWindow()
  def generate_artists_window(self,checked):
    self.t = GenerateArtistWindow()
    self.t.show()

  #Opens instance of UserSettingsWindow
  def user_settings_window(self,checked):
    self.t = UserSettingsWindow()
    self.t.show()
  





#Window prompts user to create a profile to login into future sessions
class NewUserWindow(QWidget):
  def __init__(self):
    super().__init__()

    self.setWindowTitle("New User")

    #Sets Up Title - New User
    self.label = QLabel("New User")
    font_L = self.label.font()
    font_L.setPointSize(25)
    self.label.setFont(font_L)
    self.label.setAlignment(Qt.AlignHCenter)

    #Clarifies Rules for user
    self.label2 = QLabel("Reminder: Your Profile information in SweetJimmyJams must match Spotify")
    font_s = self.label2.font()
    font_s.setPointSize(15)
    self.label2.setFont(font_s)
    self.label2.setAlignment(Qt.AlignHCenter)

    #Username input
    self.username = QLineEdit()
    self.username.setAlignment(Qt.AlignHCenter)
    self.username.setMaxLength(40)
    self.username.setFont(font_s)
    self.username.setPlaceholderText("Enter Username:")

    #Password input
    self.password = QLineEdit()
    self.password.setAlignment(Qt.AlignHCenter)
    self.password.setMaxLength(40)
    self.password.setFont(font_s)
    self.password.setPlaceholderText("Enter Password:")

    #F_Name input
    self.f_name = QLineEdit()
    self.f_name.setAlignment(Qt.AlignHCenter)
    self.f_name.setMaxLength(40)
    self.f_name.setFont(font_s)
    self.f_name.setPlaceholderText("Enter First Name:")

    #L_Name input
    self.l_name = QLineEdit()
    self.l_name.setAlignment(Qt.AlignHCenter)
    self.l_name.setMaxLength(40)
    self.l_name.setFont(font_s)
    self.l_name.setPlaceholderText("Enter Last Name:")

    #Email input
    self.email = QLineEdit()
    self.email.setAlignment(Qt.AlignHCenter)
    self.email.setMaxLength(40)
    self.email.setFont(font_s)
    self.email.setPlaceholderText("Enter Email:")

    #Submit button
    submit = QPushButton("Submit")
    submit.setFont(font_s)
    submit.clicked.connect(lambda: self.input_user())

    #Sets up page layout
    layout = QVBoxLayout()

    #Combines Widgets
    layout.addWidget(self.label)
    layout.addWidget(self.label2)
    layout.addWidget(self.username)
    layout.addWidget(self.password)
    layout.addWidget(self.f_name)
    layout.addWidget(self.l_name)
    layout.addWidget(self.email)
    layout.addWidget(submit)

    #Calls group of widgets
    self.setLayout(layout)


  def input_user(self):
    conn = sqlite3.connect("SweetJimmyJams.db")
    c = conn.cursor()

    c.execute("Select Username FROM User")
    
    valid = 1
    #Looks to see if username is already taken
    for i in c.fetchall(): 
      if(i[0] == self.username.displayText()):
        #If username is taken it returns an error window
        valid = 0
        self.error = InfoErrorWindow()
        self.error.show()
        break

    #Inserts new user info if it's not in db
    if(valid == 1):
      user_info = [self.username.displayText(),self.password.displayText(),self.f_name.displayText(),self.l_name.displayText(),self.email.displayText()]
      c.execute('INSERT INTO User VALUES (?,?,?,?,?)',user_info)

    conn.commit()
    conn.close()

    self.close()







# Window prompts user for login information for SweetJimmyJams/Spotify
class LoginWindow(QMainWindow): 
  def __init__(self,*args,**kwargs):
    super(LoginWindow,self).__init__(*args, **kwargs)

    self.setWindowTitle("Welcome to Sweet Jimmy Jams")

    #establishes title - Login
    title = QLabel("Login")
    font_L = title.font()
    font_L.setPointSize(30)
    title.setFont(font_L)
    title.setAlignment(Qt.AlignHCenter)

    #establishes title - Username
    user_T = QLabel("Username")
    font_M = user_T.font()
    font_M.setPointSize(20)
    user_T.setFont(font_M)
    user_T.setAlignment(Qt.AlignHCenter)

    #establishes username input
    self.username = QLineEdit()
    self.username.setAlignment(Qt.AlignHCenter)
    font_S = self.username.font()
    font_S.setPointSize(15)
    self.username.setFont(font_S)

    #establishes title - Password
    pass_T = QLabel("Password")
    pass_T.setFont(font_M)
    pass_T.setAlignment(Qt.AlignHCenter)

    #establishes password input
    self.password = QLineEdit()
    self.password.setAlignment(Qt.AlignHCenter)
    self.password.setFont(font_S)

    #establishes button - Submit:
    submit = QPushButton("Submit")
    submit.setFont(font_S)
    submit.clicked.connect(self.login)

    #establishes blank title
    title_space = QLabel("                      ")
    title_space.setFont(font_M)
    title_space.setAlignment(Qt.AlignHCenter)

    #establishes button - New User
    new_user = QPushButton("New User")
    new_user.setFont(font_S)
    new_user.clicked.connect(self.show_new_user_window)


    #sets up layout of the page
    pagelayout = QVBoxLayout()

    #combines widgets
    pagelayout.addWidget(title)
    pagelayout.addWidget(user_T)
    pagelayout.addWidget(self.username)
    pagelayout.addWidget(pass_T)
    pagelayout.addWidget(self.password)
    pagelayout.addWidget(submit)
    pagelayout.addWidget(title_space)
    pagelayout.addWidget(new_user)

    widgets = QWidget()
    widgets.setLayout(pagelayout)
    self.setCentralWidget(widgets)

  def login(self,checked):
    conn = sqlite3.connect("SweetJimmyJams.db")
    c = conn.cursor()

    #Checks to see if Username and password are in the database
    c.execute("Select Username,Password FROM User WHERE Username = ? and Password =?",(self.username.displayText(),self.password.displayText()))

    if(c.fetchall() != []):
      #Creates global variables for username and password to access later
      global current_username 
      current_username = self.username.displayText()
      global current_password 
      current_password = self.password.displayText()

      #Sends user to Title Window
      self.t = TitleWindow()
      self.t.show()
      valid = True

    #Shows error window if the username/password combo doesn't exist
    else:
      self.error = InfoErrorWindow()
      self.error.show()
    

    conn.commit()
    conn.close()

  #Creates an instance of NewUserWindow
  def show_new_user_window(self,checked):
    self.t = NewUserWindow()
    self.t.show()






#Runs Main
def main():
  #Makes sure the database is made
  create_database()

  #starts up UI
  app = QApplication(sys.argv)

  #Designates starting window and shows it
  StartingWindow = LoginWindow()
  StartingWindow.show()

  #Begins Program
  app.exec()

main()

conn = sqlite3.connect('SweetJimmyJams.db')
c = conn.cursor()

conn.close()