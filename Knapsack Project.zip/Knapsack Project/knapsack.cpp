#include <iostream>
#include "project2.hpp"
#include <time.h>
#include <assert.h>
#include <cstdlib>
using namespace std;

class Element1{
  public:
    int weight;
    int value;
    float ratio = (float)value/(float)weight;

    bool operator < (Element1 E){
      if(ratio<E.ratio){
        return 1;
      }
      else{
        return 0;
      }
    }

    bool operator > (Element1 E){
      if(ratio > E.ratio){
        return 1;
      }
      else{
        return 0;
      }
    }

    void operator = (Element1 E){
      weight = E.weight;
      value = E.value;
      ratio = E.ratio;
    }
};

class Element2{
  public:
    int weight;
    int value;

    bool operator < (Element2 E){
      if(weight < E.weight){
        return 1;
      }
      else{
        return 0;
      }
    }

    bool operator > (Element2 E){
      if(weight > E.weight){
        return 1;
      }
      else{
        return 0;
      }
    }

    void operator = (Element1 E){
      weight = E.weight;
      value = E.value;
    }
};

void Greedy(int max_weight,Element1 A[],const int length_array){
  HeapSort(A,length_array);
  //Invariant: A[0...end].ratio is sorted from least to greatest
  assert(isSorted(A,0,length_array-1));

  Element1 Elements[length_array];
  int total_elements = 0;
  int current_weight = 0;

  for(int i=length_array-1;i>=0;i--){
    if(current_weight + A[i].weight <= max_weight){
      Elements[total_elements] = A[i];
      total_elements++;
      current_weight+=A[i].weight;
    }
    //Invariant: currnet_weight <= max_weight
    assert(current_weight<=max_weight);
  }

  int total_value = 0;
  for(int i=0;i<total_elements;i++){
    cout<<"{ Value: "<<Elements[i].value<<", Weight: "<<Elements[i].weight<<" }"<<endl;
    total_value+=Elements[i].value;
  }

  cout<<"Total Value: "<<total_value<<endl;
  return;
}

int Max(int A, int B){
  if(A >= B){
    return A;
  }
  else{
    return B;
  }
}

void Dynamic(int max_weight,Element2 A[],const int length_array){
  int knap[length_array+1][max_weight+3];
  HeapSort(A,length_array);
  //Invariants: A[0...end].weight is sorted from least to greatest
  assert(isSorted(A,0,length_array-1));

  for(int i = 0;i<max_weight+3;i++){
    knap[0][i] = 0;
  }
  
  for(int i=0;i<length_array;i++){

    knap[i+1][0] = A[i].value;
    knap[i+1][1] = A[i].weight;
    knap[i+1][2] = 0;

  }

  for(int i=1;i<max_weight+1;i++){
    if(knap[1][1]<=i){
      knap[1][2+i] = knap[1][0];
    }
    else{
      knap[1][2+i] = 0;
    }
  }
  
  for(int j=2;j<length_array+1;j++){
    for(int i=3;i<max_weight+3;i++){
      //Invariants: knap[j][0...i-1] is sorted from least to greatest
      assert(isSorted(knap[j],3,i-1));

      if(knap[j][1] <= i-2){
        knap[j][i] = max(knap[j][0]+knap[j-1][i-knap[j][1]],knap[j-1][i]);
      }
      else{
        knap[j][i] = knap[j-1][i];
      }

      //Invariants: knap[j][0...i] is sorted from least to greatest
      assert(isSorted(knap[j],3,i));
    }
  }

  Element2 Elements[length_array];
  int total_elements = 0;
  bool end = 0;
  int column = 2 + max_weight;
  int row = length_array;
  while(end == 0){
    if(row == 0 || column <= 2){
      end = 1;
    }

    else{
      while(knap[row][column] == knap[row-1][column]){
        row--;
      }
      Elements[total_elements] = A[row-1];
      total_elements++;
      column = column-knap[row][1];
      row--;
    }
  }

  int total_value = 0;
  for(int i=0;i<total_elements;i++){
    cout<<"{ Value: "<<Elements[i].value<<", Weight: "<<Elements[i].weight<<" }"<<endl;
    total_value+=Elements[i].value;
  }

  cout<<"Total Value: "<<total_value<<endl;
  return;
}

int main(){
  const int LEN = 200;

  int weight[250] = {69, 242, 59, 222, 206, 49, 157, 246, 81, 167, 54, 237, 90, 113, 117, 204, 24, 52, 218, 225, 84, 228, 241, 18, 125, 108, 245, 145, 110, 93, 80, 109, 85, 137, 102, 57, 35, 219, 144, 132, 239, 130, 133, 193, 184, 31, 127, 12, 248, 76, 151, 32, 152, 8, 202, 205, 247, 33, 181, 190, 118, 22, 210, 75, 62, 154, 99, 17, 116, 37, 178, 98, 114, 135, 65, 48, 10, 226, 70, 25, 140, 156, 180, 21, 162, 3, 170, 139, 124, 230, 86, 126, 101, 201, 66, 212, 166, 30, 221, 79, 58, 194, 211, 232, 164, 51, 78, 67, 234, 136, 77, 214, 176, 197, 229, 9, 73, 71, 168, 20, 155, 6, 240, 55, 196, 13, 200, 141, 187, 23, 231, 42, 1, 224, 188, 50, 159, 203, 185, 105, 63, 96, 208, 14, 244, 92, 26, 199, 191, 43, 158, 186, 179, 122, 153, 217, 103, 61, 115, 138, 149, 28, 68, 94, 143, 146, 131, 119, 5, 147, 7, 209, 95, 243, 160, 91, 198, 235, 163, 134, 174, 106, 227, 56, 233, 47, 27, 249, 72, 182, 29, 165, 74, 104, 11, 45, 183, 129, 36, 150, 236, 39, 148, 34, 112, 177, 195, 53, 189, 89, 175, 40, 38, 207, 121, 100, 83, 82, 173, 111, 220, 87, 46, 213, 123, 171, 15, 19, 41, 44, 172, 223, 88, 250, 64, 215, 142, 16, 120, 2, 192, 60, 4, 169, 97, 216, 107, 238, 128, 161};
  int value[250] = {48, 250, 212, 123, 165, 30, 47, 218, 132, 160, 95, 5, 74, 236, 20, 28, 50, 116, 135, 151, 61, 138, 154, 26, 125, 178, 41, 214, 136, 65, 32, 51, 168, 39, 222, 117, 247, 193, 235, 90, 210, 1, 243, 69, 21, 10, 248, 35, 126, 96, 183, 102, 134, 59, 191, 167, 37, 53, 113, 62, 184, 190, 63, 196, 107, 34, 246, 85, 142, 45, 56, 38, 182, 11, 242, 159, 111, 175, 93, 97, 200, 194, 176, 73, 17, 169, 131, 87, 83, 40, 140, 145, 223, 86, 25, 220, 150, 198, 238, 203, 7, 147, 60, 70, 19, 46, 15, 119, 171, 219, 55, 141, 127, 228, 161, 100, 186, 24, 49, 122, 187, 78, 177, 180, 103, 227, 121, 244, 239, 152, 99, 110, 172, 124, 98, 192, 156, 148, 104, 54, 79, 245, 64, 84, 188, 114, 129, 249, 226, 181, 27, 120, 94, 197, 137, 31, 146, 128, 240, 80, 105, 82, 158, 221, 8, 108, 149, 195, 202, 162, 139, 173, 77, 233, 4, 109, 179, 237, 201, 2, 174, 16, 208, 75, 29, 205, 230, 57, 241, 185, 3, 231, 58, 88, 170, 67, 153, 163, 92, 89, 12, 217, 207, 133, 189, 204, 9, 18, 232, 23, 118, 225, 14, 6, 106, 143, 22, 91, 33, 157, 101, 52, 66, 224, 68, 216, 112, 209, 43, 199, 206, 211, 13, 166, 164, 42, 155, 44, 71, 234, 144, 229, 130, 36, 76, 215, 213, 81, 72, 115};

  Element1 A[LEN];
  Element2 B[LEN];

  for(int i=0;i<LEN;i++){
    A[i].weight=weight[i];
    B[i].weight=weight[i];
    A[i].value=value[i];
    B[i].value=value[i];
    A[i].ratio=(float)A[i].value/(float)A[i].weight;
  }

  cout<<(double)clock()/CLOCKS_PER_SEC<<endl;
  Greedy(500,A,LEN);
  cout<<(double)clock()/CLOCKS_PER_SEC<<endl;

  cout<<(double)clock()/CLOCKS_PER_SEC<<endl;
  Dynamic(500,B,LEN);
  cout<<(double)clock()/CLOCKS_PER_SEC<<endl;

  return 0;
}