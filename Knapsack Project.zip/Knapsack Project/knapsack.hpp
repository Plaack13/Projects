#include <iostream>
#include <assert.h>
using namespace std;

template <typename T>
bool isSorted(T array[],int start,int end){
  for(int i = start;i<end;i++){
    if(array[i] > array[i+1]){
      return false;
    }
  }
  return true;
}

template <typename T>
bool isMaxHeap(T array[],int inner_node_start,int inner_node_end,int length){
  for(int i = inner_node_start;i<inner_node_end;i++){
    if((array[i]<array[i*2+2] && i*2+2 < length) || (array[i]<array[i*2+1] && i*2+1 < length)){
      return false;
    }
  }
  return true;
}

template <typename T>
void HeapSort(T A[], const int length){
  int len_A = length;
  
  for(int i=0;i<length;i++){
    //I(length-1): A[length-2-i...length-1] is sorted
    assert(isSorted(A,length-i,length-1));
    int inner_nodes = len_A/2;
    
    for(int j = inner_nodes-1;j>=0;j--){
      //I(j-1): A[0....j-1] is a max heap
      assert(isMaxHeap(A,j+1,inner_nodes,len_A));
      int shift = j;
      int child_l = shift*2+1;
      int child_r = shift*2+2;
      while((A[shift]<A[child_l] && child_l < len_A)|| (A[shift] < A[child_r] && child_r < len_A)){

        if(A[child_l] < A[child_r] && child_r < len_A){
          T tmp = A[shift];
          A[shift] = A[child_r];
          A[child_r] = tmp;
          shift = (shift*2) + 2;
          child_l = shift*2+1;
          child_r = shift*2+2;
        }

        else if((A[child_l] > A[child_r] || child_r >= len_A) && child_l < len_A){
          
          T tmp = A[shift];
          A[shift] = A[child_l];
          A[child_l] = tmp;
          shift = (shift*2) + 1;
          child_l = shift*2+1;
          child_r = shift*2+2;
        }
      }
      //I(j): A[0....j] is a max heap
      assert(isMaxHeap(A,j,inner_nodes,len_A));
    }
    
    len_A--;
    T tmp = A[0];
    A[0] = A[len_A];
    A[len_A] = tmp;

    //I(length-1): A[length-2-i...length-1] is sorted
    assert(isSorted(A,length-1-i,length-1));
  }
  return;
}